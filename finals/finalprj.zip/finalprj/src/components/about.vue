<template>
    <div class="contact"> 
    
    <h1>Lee, Miguel P.</h1>
    <h2>Web Developer</h2>
    <h3>I am Miguel Lee from Holy Angel University. Currently 2nd year College taking Bachelor of Science in Web Development</h3>
    <h3>skills/Interest</h3>
    <h4>Web Designing</h4>
    <h4>Cooking</h4>
    
    </div>
</template>

<script>
    export default{
        name: 'about', 
        data (){
            return {
                title: 'About'
        }
    }
}
</script>
<style scoped>
*{
  background-color: #D3D3D3;
  font-family: 'Times New Roman', Times, serif;
}
h1 {
  font-size: 5rem;
  margin: 0 0 0.5rem;
}

h2 {
  font-size: 1.5rem;
  margin: 0 0 1rem;
}

h3 {
  font-size: 1.5rem;
  margin: 0 0 1rem;
}

h4 {
  font-size: 1.5rem;
  margin: 0 0 1rem;
}

</style>