<template>
    <div class="contact"> 
        <h1>Welcome To Contact!</h1>
        <img src="../assets/contact.jpg">
        <h3>IF you need any queries!</h3>
        <h3>Please contact this no.!</h3>
        <h3>#09675600013</h3>
    </div>
</template>

<script>
    export default{
        name: 'contact', 
        data (){
            return {
                title: 'Contact'
        }
    }
}
</script>
<style scoped>
img {
    width: 30%;
    display: block;
    margin-left: auto;
    margin-right: auto;
}
h1, h3 {
    font-family: 'Times New Roman', Times, serif;
    background-color: #D3D3D3;
}
</style>