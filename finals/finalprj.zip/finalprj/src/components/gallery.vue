<template>
    <div class="gallery"> 
        <h1>{{title}}</h1>
        <img src="../assets/gallery1.png">
        <img src="../assets/gallery2.jpg">
        <img src="../assets/gallery3.jpg">
        <img src="../assets/gallery4.jpg">
    </div>
</template>

<script>
    export default{
        name: 'gallery', 
        data (){
            return {
                title: 'Gallery'
        }
    }
}
</script>
<style scoped>
img {
    width: 30%;
    display: block;
    margin-left: auto;
    margin-right: auto;
    padding: 20px;
}
h1 {
    font-family: 'Times New Roman', Times, serif;
    text-align: center;
    color: black;
}

.gallery {
  padding: 60px;
  text-align: center;
  background: #ffcaaf;
  color: white;
  font-size: 30px;
}
</style>