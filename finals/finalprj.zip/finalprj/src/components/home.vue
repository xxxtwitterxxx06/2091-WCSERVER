<template>
  <div class="home">
    <h1>Welcome! to My Home page!</h1>
    <h3>Let's Get Started!</h3>
  </div>
</template>

<script>
  export default{
    name: 'home',
    data(){
      return{
        msg: 'Welcome to Your Vue.js App'
      }
    }
  }
</script>

<!--Add "scoped" attribute to limit CSS to this component only-->
<style scoped>
h1, h3 {
    font-family: 'Times New Roman', Times, serif;
}

.home {
  padding: 60px;
  text-align: center;
  background: #ffcaaf;
  color: white;
  font-size: 30px;
}
</style>